int hex_correlations( int, double * , double * , double *, double *, double , double, double, char *); 
