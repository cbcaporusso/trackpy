import numpy as np
from confs import Conf
from scipy.signal import correlate
from traj.box import Box 
import ctypes
import time
import os

def spatial_hex_correlation(conf: Conf):
    # load hexatic
    times = conf.find_configuration_times(-10)
    for tt in times: 

        box = Box.from_dump(conf.filepath('trj', tt))
        pos, psi6 = hex_data = conf.load_hexatic(tt)
        
        pos.astype(np.float16)

        box_size = np.min(box.L)

        # compute correlation
        dr = 1.0
        n_parts = pos.shape[0]
        n_cells = int(box_size / dr)

        corrs = np.zeros(n_cells)
        counter = np.zeros(n_cells)

        # points in the square box_size, box_size
        mask = np.logical_and(pos[:, 0] < box_size, pos[:, 1] < box_size)
        pos = pos[mask]
        psi6 = psi6[mask]

        start = time.time()
        for i, xi, pi in zip(range(pos.shape[0]), pos, psi6):
            perc = 100 * i / pos.shape[0]
            print(f'{perc:.2f} %', end='\r')
            if round(perc,2) == 0.10:
                end = time.time()
                print(f'Elapsed time: {end - start:.2f} s')
                break 

            # compute distance array 
            dist = np.linalg.norm(box.distance_pbc(pos, xi), axis=1)
            dist_index = np.floor(dist / dr).astype(int)
            for j, index in enumerate(dist_index):
                pj = psi6[j]
                corrs[index] += np.dot(pi, pj)
                counter[index] += 1

        corrs = np.where(counter > 0, corrs / counter, 0)
        return corrs 
        

def fast_hex_correlation(conf, time, skip_existing=True):

    base_path = conf.filepath()
    out_name = f'{base_path}/correlations/xyz.dump.{time}'
    
    if os.path.exists(out_name) and skip_existing:
        print(f"Correlation {out_name} already computed. Skipping.")
        return 0


    box = Box.from_dump(conf.filepath('trj', time))

    pos, psi6 = conf.load_hexatic(time)

    os.makedirs(f'{base_path}/correlations', exist_ok=True)

    corr_lib = np.ctypeslib.load_library('corr.so', '/gpfs/projects/ub35/demian/chiral/lib')
    hcorr_f = corr_lib.hex_correlations
    hcorr_f.restype = ctypes.c_int

    ntot = len(pos[:, 0])

    pos_x = np.ctypeslib.as_ctypes(np.ascontiguousarray(pos[:, 0]))
    pos_y = np.ctypeslib.as_ctypes(np.ascontiguousarray(pos[:, 1]))
    hex_re = np.ctypeslib.as_ctypes(np.ascontiguousarray(psi6[:, 0]))
    hex_im = np.ctypeslib.as_ctypes(np.ascontiguousarray(psi6[:, 1]))

    lx = ctypes.c_double(box.lx)
    ly = ctypes.c_double(box.ly)

    out_name = ctypes.c_char_p(out_name.encode('utf-8'))

    result = hcorr_f(ntot, pos_x, pos_y, hex_re, hex_im,
                     lx, ly, ctypes.c_double(1.0), out_name)

    return result
