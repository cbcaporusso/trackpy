# TRACKPY

Track-py is a Python package for post-processing analysis of particle-based simulations.

## Installation
